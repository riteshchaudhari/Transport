import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping(value="/home")
public class controller {

	public controller() {
	System.out.println("In Constructor");
	}
	
	public String test() {
		System.out.println("In Controller");
		return "home";
	}
}
